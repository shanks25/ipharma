        <!-- footer content -->
        <footer>
          <div class="pull-right">
              Ipharma Limited Admin Developed by <a href="https://drogenidesoftwares.com/" target="_blank">Drogenide Softwares</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <script src="{{URL::asset('assets/jquery/dist/jquery.min.js')}}"></script>
    <script src="{{URL::asset('assets/bootstrap/js/bootstrap.min.js')}}"></script>
    <script src="{{URL::asset('assets/bootstrap-progressbar/bootstrap-progressbar.min.js')}}"></script>
    <script src="{{URL::asset('assets/datatable/jquery.dataTables.min.js')}}"></script>
    <script src="{{URL::asset('assets/datatable/dataTables.bootstrap.min.js')}}"></script>
    <script src="{{URL::asset('assets/icheck/icheck.min.js')}}"></script>
    <script src="{{URL::asset('assets/toastr/toastr.min.js')}}"></script>
    <script src="{{URL::asset('assets/handlebars/handlebars-v4.0.5.js') }}"></script>
    <script src="{{URL::asset('assets/select2/js/select2.min.js') }}"></script>
    <script src="{{URL::asset('assets/sweetalert2/sweetalert2.min.js') }}"></script>
    <script src="{{ URL::asset('assets/jQuery-Smart-Wizard-master/js/jquery.smartWizard.js') }}"></script>
    
    <script src="{{URL::asset('js/summernote.min.js')}}"></script>
    <script src="{{URL::asset('js/dropzone.min.js')}}"></script>
    <script src="{{URL::asset('js/jquery.domenu-0.100.77.js')}}"></script>
    <!-- Custom Theme Scripts -->
    <script src="{{URL::asset('js/gentelella.min.js')}}"></script>
    <script src="{{URL::asset('js/epharma.js')}}"></script>

  @stack('scripts')
  <!--Start of Tawk.to Script-->
 
<!--End of Tawk.to Script-->
  </body>

</html>